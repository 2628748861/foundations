package com.plugin.foundation.library.image.shape;

/**圆角形状
 * @param <T>
 */
public abstract class CornerShape<T> {
    public abstract T getShape();
}
